## Picker

 <!-- ![Image of Fulfillment Supervisor, Daniel Green](https://cdn.shopify.com/s/files/1/0018/5932/1925/files/images_4_2048x.jpg?v=1537463701 "Daniel Green") -->
 ![Image of Fulfillment Supervisor, Daniel Green](Daniel.jpg "Daniel Green")
  
 ### Demographics:
  Full Name:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**Daniel Green**
  Age: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**23 years old**   
  Gender:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**Male**
  Education:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**GED**
  Occupation:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**Filfillment Operator**     

 ### About Daniel:
   Danile is a self reliant person.

   Since Daniel tries to keep it to himself and does not prefer outside help, he usually ends up taking time to learn new things.   
   This sometimes leads to him not being able to use the equipment provided to him in an efficient manner.   
   Daniel takes his work lightly and isn't always focussed thus reprinting labels and repacking items usually takes place at his workstation more than expected.   
   Daniel like to have his own logic behind how things should be done and does not always follow procedures set by the supervisors.  

 ### Understanding of Technology:
   **IT/Internet**  ---------*-     **90%**   
   **Software**     -------*---     **75%**   
   **Mobile**       ---------*-     **95%** 
   
  ### Company Profile:
   Title:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**Picker**   
   Email:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**dGreen@complemar.com**
   Employee ID:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**0003**   
   Location:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**Rochester**   
   Hire Date:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**Feb 14, 2018**   
   Department:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**Operations**   
   pack Rate:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**_______**   
   
  ### System Access:
   [x]&nbsp;&nbsp;&nbsp;&nbsp;Comet   
   [ ]&nbsp;&nbsp;&nbsp;&nbsp;WMS   
   [x]&nbsp;&nbsp;&nbsp;&nbsp;GUN APP   
   [ ]&nbsp;&nbsp;&nbsp;&nbsp;PROSHIP   
   
  ### Training:
   [x]&nbsp;&nbsp;&nbsp;&nbsp;New Hire Orientation   
   [x]&nbsp;&nbsp;&nbsp;&nbsp;HIPPA Training   
   [x]&nbsp;&nbsp;&nbsp;&nbsp;Weight Counting   
   [x]&nbsp;&nbsp;&nbsp;&nbsp;Good documentation Practices   
   [x]&nbsp;&nbsp;&nbsp;&nbsp;Inventory Accuracy
   [x]&nbsp;&nbsp;&nbsp;&nbsp;Label Printing  
   [x]&nbsp;&nbsp;&nbsp;&nbsp;First Piece
   [x]&nbsp;&nbsp;&nbsp;&nbsp;Accident Form1
   [x]&nbsp;&nbsp;&nbsp;&nbsp;Accident Form2   
   [ ]&nbsp;&nbsp;&nbsp;&nbsp;Quality Alert Roche Cage QTY
   [ ]&nbsp;&nbsp;&nbsp;&nbsp;Incomming Material Inspection
   [x]&nbsp;&nbsp;&nbsp;&nbsp;Safety and Fire   
   [x]&nbsp;&nbsp;&nbsp;&nbsp;Tablet     

  ### Presonality:
   #### Openness                                      (65%)
    **Imagination**             -------*---      Above-Average   
    **Artistic interest**       -------*---      Above-Average   
    **Emotionality**            ------*----      Average   
    **Adventorous**             -------*---      Above-Average   
    **Liberalism**              -----*-----      Average   
    **Intellect**               -----*-----      Average   
   
   #### Conscientiousness                             (60%)
    **Self-efficiency**         --------*--      High   
    **Orderliness**             ----*------      Below-Average   
    **Dutifulness**             -----*-----      Average   
    **Achievement-striving**    -----*-----      Average   
    **self-disciplined**        -----*-----      Average   
    **Cautiousness**            -----*-----      Average   
   
   #### Extraversion                                  (55%)
    **Friendliness**            ----*------      Below-Average   
    **Gregatiousness**          ------*----      Average   
    **Assertiveness**           ------*----      Average   
    **Activity-level**          -------*---      Above-Average   
    **Excitement seeking**      -------*---      Above-Average   
    **Cheerfulness**            -------*---      Above-Average   
   
   #### Agreeable                                     (55%)
    **Trust**                   ------*----      Average   
    **Morality**                ------*----      Average   
    **Altruism**                ----*------      Below-Average   
    **Cooperation**             -------*---      Above-Average   
    **Modesty**                 ------*----      Average   
    **Sympathy**                -----*-----      Average   
   
   #### Neuroticism                                   (45%)
    **Anxiety**                 -----*-----      Average   
    **Anger**                   -*---------      Low   
    **Depression**              --*--------      Low   
    **Self-consciousness**      -----*-----      Average   
    **Immoderation**            ---*-------      Low   
    **Vulnerability**           -------*---      Above-Average   
    
  ### Tags:
   ```strong```, ```self-reliant```, ```ateletic```, ```co-operative```, ```inconsistent```, ```Introvert```, ```smart```, ```tech-savvy```.