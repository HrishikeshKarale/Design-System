## Picker

 <!-- ![Image of Fulfillment Supervisor, Noah Harper](https://cdn.shopify.com/s/files/1/0018/5932/1925/files/images_4_2048x.jpg?v=1537463701 "Noah Harper") -->
 ![Image of Fulfillment Supervisor, Noah Harper](Noah.jpg "Noah Harper")
  
 ### Demographics:
  Full Name:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**Noah Harper**
  Age: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**28 years old**   
  Gender:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**Male**
  Education:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**GED**
  Occupation:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**Filfillment Operator**     

 ### About Daniel:
   Noha is a very social person and has a relaxed attitude.

   He has a strong social presence and everyone knows Noah.   
   He has a tendency of getting carried away in a conversation and as a result in a less productivity.   
   Noah keeps the Moral of his co-workers up but is also a culprit in engaging them in long conversations while working resulting in lack of focus and slower production rate from everyone.    
   Noha is also known to make mistakes due to his personality traits and has a Higher than average re-pack and re-print label rate.   

 ### Understanding of Technology:
   **IT/Internet**  -------^---     **75%**   
   **Software**     --------^--     **75%**   
   **Mobile**       --------^--     **85%** 
   
  ### Company Profile:
   Title:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**Picker**   
   Email:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**nHarper@complemar.com**
   Employee ID:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**0004**   
   Location:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**Rochester**   
   Hire Date:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**May 1, 2018**   
   Department:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**Operations**   
   pick Rate:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**_______**   
   
  ### System Access:
   [x]&nbsp;&nbsp;&nbsp;&nbsp;Comet   
   [ ]&nbsp;&nbsp;&nbsp;&nbsp;WMS   
   [x]&nbsp;&nbsp;&nbsp;&nbsp;GUN APP   
   [ ]&nbsp;&nbsp;&nbsp;&nbsp;PROSHIP   
   
  ### Training:
   [x]&nbsp;&nbsp;&nbsp;&nbsp;New Hire Orientation   
   [x]&nbsp;&nbsp;&nbsp;&nbsp;HIPPA Training   
   [x]&nbsp;&nbsp;&nbsp;&nbsp;Weight Counting   
   [x]&nbsp;&nbsp;&nbsp;&nbsp;Good documentation Practices   
   [x]&nbsp;&nbsp;&nbsp;&nbsp;Inventory Accuracy
   [x]&nbsp;&nbsp;&nbsp;&nbsp;Label Printing  
   [x]&nbsp;&nbsp;&nbsp;&nbsp;First Piece
   [x]&nbsp;&nbsp;&nbsp;&nbsp;Accident Form1
   [x]&nbsp;&nbsp;&nbsp;&nbsp;Accident Form2   
   [ ]&nbsp;&nbsp;&nbsp;&nbsp;Quality Alert Roche Cage QTY
   [ ]&nbsp;&nbsp;&nbsp;&nbsp;Incomming Material Inspection
   [x]&nbsp;&nbsp;&nbsp;&nbsp;Safety and Fire   
   [x]&nbsp;&nbsp;&nbsp;&nbsp;Tablet     

  ### Presonality:
   #### Openness                                      (65%)
    **Imagination**             --------*--      High   
    **Artistic interest**       -------*---      Above-Average   
    **Emotionality**            ------*----      Average   
    **Adventorous**             ------*----      Average   
    **Liberalism**              -----*-----      Average   
    **Intellect**               ------*----      Average   
   
   #### Conscientiousness                             (40%)
    **Self-efficiency**         -*---------      Low   
    **Orderliness**             ----*------      Below-Average   
    **Dutifulness**             ----*------      Below-Average   
    **Achievement-striving**    -----*-----      Average   
    **self-disciplined**        -----*-----      Average   
    **Cautiousness**            -*---------      Low   
   
   #### Extraversion                                  (75%)
    **Friendliness**            --------*--      High   
    **Gregatiousness**          ------*----      Average   
    **Assertiveness**           ------*----      Average   
    **Activity-level**          --------*--      High   
    **Excitement seeking**      ------*----      Average   
    **Cheerfulness**            --------*--      High   
   
   #### Agreeable                                     (35%)
    **Trust**                   ------*----      Average   
    **Morality**                ------*----      Average   
    **Altruism**                -*---------      Low   
    **Cooperation**             -------*---      Above-Average   
    **Modesty**                 ----*------      Below-Average   
    **Sympathy**                ----*------      Below-Average   
   
   #### Neuroticism                                   (35%)
    **Anxiety**                 -*---------      Low   
    **Anger**                   -*---------      Low   
    **Depression**              -----*-----      Average   
    **Self-consciousness**      -----*-----      Average   
    **Immoderation**            --*--------      Low   
    **Vulnerability**           -----*-----      Average   
    
  ### Tags:
   ```tech savvy```, ```charming```, ```social```, ```relaxed```, ```educated```, ```Extrovert```, ```cheerfull```.