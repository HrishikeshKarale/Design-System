## Wendy

 <!-- ![Wendy Marvell](https://c1.staticflickr.com/8/7031/6698571299_28362104b2_b.jpg "Wendy Marvell") -->
 ![Wendy Marvell](Wendy.jpg "Wendy Marvell")
  
 ### Demographics:
  Full Name:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**Wendy Marvell**
  Age: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**31 years old**   
  Gender:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**Female**
  Education:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**HighSchool Diploma**
  Occupation:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**Fulfillment Operator**     

  ### About Wendy:
   Wendy is very focussed towards work and has a goal oriented mentality.   
   She has a good understanding about the cross dock process and the general working of Complemar.
   Wendy utilizes her previous experience with fulfillment and takes her work seriously.   
   She is a crutial part in the process and keep the line running efficiently.   
   Wendy is known to follow proedures and has a good track record. She rarely makes mistake.   

  ### Understanding of Technology:
    **IT/Internet**  --------*--     **80%**   
    **Software**     --------*--     **80%**   
    **Mobile**       --------*--     **80%** 
   
  ### Company Profile:
   Title:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**Cross-dock Operator II**   
   Email:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**wMarvell@complemar.com**
   Employee ID:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**0001**   
   Location:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**Rochester**   
   Hire Date:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**April 22, 2018**   
   Department:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**Operations**   
   
  ### Performance:
   Cross-dock Rate:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**2.00 packages/minute** (delta +-0.2) 
   
  ### System Access:
   [x]&nbsp;&nbsp;&nbsp;&nbsp;Comet   
   [ ]&nbsp;&nbsp;&nbsp;&nbsp;WMS   
   [x]&nbsp;&nbsp;&nbsp;&nbsp;GUN APP   
   [ ]&nbsp;&nbsp;&nbsp;&nbsp;PROSHIP   
   
  ### Training:
   [x]&nbsp;&nbsp;&nbsp;&nbsp;New Hire Orientation   
   [x]&nbsp;&nbsp;&nbsp;&nbsp;HIPPA Training   
   [x]&nbsp;&nbsp;&nbsp;&nbsp;Weight Counting   
   [x]&nbsp;&nbsp;&nbsp;&nbsp;Good documentation Practices   
   [x]&nbsp;&nbsp;&nbsp;&nbsp;Inventory Accuracy
   [x]&nbsp;&nbsp;&nbsp;&nbsp;Label Printing  
   [x]&nbsp;&nbsp;&nbsp;&nbsp;First Piece
   [x]&nbsp;&nbsp;&nbsp;&nbsp;Accident Form1
   [x]&nbsp;&nbsp;&nbsp;&nbsp;Accident Form2   
   [ ]&nbsp;&nbsp;&nbsp;&nbsp;Quality Alert Roche Cage QTY
   [ ]&nbsp;&nbsp;&nbsp;&nbsp;Incomming Material Inspection
   [x]&nbsp;&nbsp;&nbsp;&nbsp;Safety and Fire   
   [x]&nbsp;&nbsp;&nbsp;&nbsp;Tablet     

  ### Presonality:
   #### Openness                                      (60%)
    **Imagination**             ------*----      Average   
    **Artistic interest**       -------*---      Above-Average   
    **Emotionality**            ------*----      Average   
    **Adventorous**             ------*----      Average   
    **Liberalism**              -----*-----      Average   
    **Intellect**               --------*--      Above-Average   
    
   #### Conscientiousness                             (90%)
    **Self-efficiency**         --------*--      Above-Average   
    **Orderliness**             --------*--      High   
    **Dutifulness**             ---------*-      High   
    **Achievement-striving**    ---------*-      High   
    **self-disciplined**        --------*--      High   
    **Cautiousness**            --------*--      Above-Average  
   
   #### Extraversion                                  (60%)
    **Friendliness**            ------*----      Average   
    **Gregatiousness**          -------*---      Above-Average   
    **Assertiveness**           ------*----      Average   
    **Activity-level**          -----*-----      Average   
    **Excitement seeking**      ----*------      Below-Average   
    **Cheerfulness**            ------*----      Average   
   
   #### Agreeable                                     (75%)
    **Trust**                   --------*--      High   
    **Morality**                --------*--      High   
    **Altruism**                ----*------      Below-Average   
    **Cooperation**             --------*--      High   
    **Modesty**                 --------*--      High   
    **Sympathy**                -----*-----      Average  
   
   #### Neuroticism                                   (30%)
    **Anxiety**                 --*--------      Low   
    **Anger**                   -*---------      Low   
    **Depression**              --*--------      Low   
    **Self-consciousness**      -----*-----      Average   
    **Immoderation**            ---*-------      Low   
    **Vulnerability**           --*--------      Low   
    
  ### Tags:
   ```tech-savvy```, ```reliable```, ```consistent```, ```organized```, ```goal-oriented```, ```focussed```, ```social```, ```attentive```. 