## Fulfillment Supervisor


 <!-- ![Image of Fulfillment Supervisor, Scott Collins](https://www.dailyherald.com/storyimage/DA/20111121/business/711219977/EP/1/2/EP-711219977.jpg&updated=201111200846&MaxW=600&maxH=600&noborder "Scott Collins") -->
  ![Image of Fulfillment Supervisor, Scott Collins](Scott.jpg "Scott Collins")

 ### Demographics:
  Full Name:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**Scott Collins**
  Age: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**46 years old**   
  Gender:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**Male**
  Education:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**HighSchool Diploma**
  Occupation:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**Fulfillment Supervisor**     

 ### About Scott:
  Scott is a Problem solver.
  
  His experience within the warehouse and fulfillment industry makes him a very dependable person.   
  Because of his experience Scott is a goto person whenever it comes to problems in the process or possible solutions to address those flaws in the system.   
  he has a good understanding about the inner working of the system and deals with patience.   
  Scott runs his station at a consistent pace and has a very good record.   
  Scott volunteers when it comes to teaching new people about hiw the system works and about the common ways to deal with day to day problems.     

 ### Understanding of Technology:
  **IT/Internet**  ------*----     **60%**   
  **Software**     -------*---     **65%**   
  **Mobile**       -----*-----     **55%** 
   
  ### Company Profile:
   Title:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**Fulfillment Supervisor III**   
   Email:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**sCollins@complemar.com**
   Employee ID:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**0002**   
   Location:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**Rochester**   
   Hire Date:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**July 22, 2018**   
   Department:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**Operations**   
   
  ### System Access:
   [x]&nbsp;&nbsp;&nbsp;&nbsp;Comet   
   [x]&nbsp;&nbsp;&nbsp;&nbsp;WMS   
   [x]&nbsp;&nbsp;&nbsp;&nbsp;GUN APP   
   [x]&nbsp;&nbsp;&nbsp;&nbsp;PROSHIP   
   
  ### Training:
   [x]&nbsp;&nbsp;&nbsp;&nbsp;New Hire Orientation   
   [x]&nbsp;&nbsp;&nbsp;&nbsp;HIPPA Training   
   [x]&nbsp;&nbsp;&nbsp;&nbsp;Weight Counting   
   [x]&nbsp;&nbsp;&nbsp;&nbsp;Good documentation Practices   
   [x]&nbsp;&nbsp;&nbsp;&nbsp;Inventory Accuracy
   [x]&nbsp;&nbsp;&nbsp;&nbsp;Label Printing  
   [x]&nbsp;&nbsp;&nbsp;&nbsp;G and D Verizon Card Line
   [x]&nbsp;&nbsp;&nbsp;&nbsp;Accident Form1
   [x]&nbsp;&nbsp;&nbsp;&nbsp;Accident Form2   
   [x]&nbsp;&nbsp;&nbsp;&nbsp;Attendance Policies
   [x]&nbsp;&nbsp;&nbsp;&nbsp;Extra Items / Over Pick Process
   [x]&nbsp;&nbsp;&nbsp;&nbsp;Safety and Fire   
   [x]&nbsp;&nbsp;&nbsp;&nbsp;ISO Audit Finding Review  
   [x]&nbsp;&nbsp;&nbsp;&nbsp;Communication 100   

  ### Presonality:
   #### Openness                                      (70%)
    **Imagination**             ------*----      Average   
    **Artistic interest**       ------*----      Average   
    **Emotionality**            ------*----      Average   
    **Adventorous**             -------*---      Above-Average   
    **Liberalism**              -----*-----      Average   
    **Intellect**               --------*--      High   
    
   #### Conscientiousness                             (75%)
    **Self-efficiency**         -------*---      Above-Average   
    **Orderliness**             -------*---      Above-Average   
    **Dutifulness**             -----*-----      Average   
    **Achievement-striving**    -----*-----      Average   
    **self-disciplined**        -----*-----      Average   
    **Cautiousness**            -----*-----      Average   
   
   #### Extraversion                                  (60%)
    **Friendliness**            -------*---      Above-Average   
    **Gregatiousness**          ------*----      Average   
    **Assertiveness**           ------*----      Average   
    **Activity-level**          ----*------      Below-Average   
    **Excitement seeking**      -*---------      Low   
    **Cheerfulness**            ------*----      Average   
   
   #### Agreeable                                     (65%)
    **Trust**                   -------*---      Above-Average   
    **Morality**                -------*---      Above-Average   
    **Altruism**                ------*----      Average   
    **Cooperation**             ------*----      Average   
    **Modesty**                 -------*---      Above-Average   
    **Sympathy**                -------*---      Above-Average   
   
   #### Neuroticism                                   (25%)
    **Anxiety**                 -*---------      Low   
    **Anger**                   -*---------      Low   
    **Depression**              --*--------      Low   
    **Self-consciousness**      -----*-----      Average   
    **Immoderation**            -----*-----      Average   
    **Vulnerability**           --*--------      Low   
    
 ### Tags:
  ```strong```, ```problem solver```, ```social```, ```co-operative```, ```consistent```, ```friendly```, ```reliable```, ```witty```, ```cheerfull```.